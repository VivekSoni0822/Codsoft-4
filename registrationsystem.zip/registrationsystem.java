import java.util.ArrayList;
import java.util.List;

class Course {
    private String courseCode;
    private String title;
    private String description;
    private int capacity;
    private String schedule;
    private List<Student> registeredStudents;

    public Course(String courseCode, String title, String description, int capacity, String schedule) {
        this.courseCode = courseCode;
        this.title = title;
        this.description = description;
        this.capacity = capacity;
        this.schedule = schedule;
        this.registeredStudents = new ArrayList<>();
    }

    public String getCourseCode() {
        return courseCode;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public int getCapacity() {
        return capacity;
    }

    public String getSchedule() {
        return schedule;
    }

    public List<Student> getRegisteredStudents() {
        return registeredStudents;
    }

    public int getAvailableSlots() {
        return capacity - registeredStudents.size();
    }

    public boolean registerStudent(Student student) {
        if (registeredStudents.size() < capacity) {
            registeredStudents.add(student);
            return true;
        }
        return false;
    }

    public boolean dropStudent(Student student) {
        return registeredStudents.remove(student);
    }

    @Override
    public String toString() {
        return "Course Code: " + courseCode + ", Title: " + title + ", Description: " + description +
                ", Capacity: " + capacity + ", Schedule: " + schedule + ", Available Slots: " + getAvailableSlots();
    }
}

class Student {
    private String studentId;
    private String name;
    private List<Course> registeredCourses;

    public Student(String studentId, String name) {
        this.studentId = studentId;
        this.name = name;
        this.registeredCourses = new ArrayList<>();
    }

    public String getStudentId() {
        return studentId;
    }

    public String getName() {
        return name;
    }

    public List<Course> getRegisteredCourses() {
        return registeredCourses;
    }

    public boolean registerForCourse(Course course) {
        if (course.registerStudent(this)) {
            registeredCourses.add(course);
            return true;
        }
        return false;
    }

    public boolean dropCourse(Course course) {
        if (course.dropStudent(this)) {
            registeredCourses.remove(course);
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Student ID: " + studentId + ", Name: " + name;
    }
}

public class CourseManagementSystem {
    private List<Course> courses;
    private List<Student> students;

    public CourseManagementSystem() {
        this.courses = new ArrayList<>();
        this.students = new ArrayList<>();
    }

    public void addCourse(Course course) {
        courses.add(course);
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public List<Course> listCourses() {
        return courses;
    }

    public Course findCourse(String courseCode) {
        for (Course course : courses) {
            if (course.getCourseCode().equals(courseCode)) {
                return course;
            }
        }
        return null;
    }

    public Student findStudent(String studentId) {
        for (Student student : students) {
            if (student.getStudentId().equals(studentId)) {
                return student;
            }
        }
        return null;
    }

    public boolean registerStudentForCourse(String studentId, String courseCode) {
        Student student = findStudent(studentId);
        Course course = findCourse(courseCode);
        if (student != null && course != null) {
            return student.registerForCourse(course);
        }
        return false;
    }

    public boolean dropStudentFromCourse(String studentId, String courseCode) {
        Student student = findStudent(studentId);
        Course course = findCourse(courseCode);
        if (student != null && course != null) {
            return student.dropCourse(course);
        }
        return false;
    }

    public static void main(String[] args) {
        CourseManagementSystem cms = new CourseManagementSystem();

        Course course1 = new Course("CS101", "Introduction to Computer Science", "Basic concepts of computer science", 30, "MWF 9-10AM");
        Course course2 = new Course("MATH101", "Calculus I", "Introduction to calculus", 40, "TTh 10-11:30AM");
        
        cms.addCourse(course1);
        cms.addCourse(course2);

        Student student1 = new Student("S001", "Alice");
        Student student2 = new Student("S002", "Bob");

        cms.addStudent(student1);
        cms.addStudent(student2);

        System.out.println("Available Courses:");
        for (Course course : cms.listCourses()) {
            System.out.println(course);
        }

        System.out.println("\nRegistering Alice for CS101:");
        cms.registerStudentForCourse("S001", "CS101");
        System.out.println(course1);

        System.out.println("\nDropping Alice from CS101:");
        cms.dropStudentFromCourse("S001", "CS101");
        System.out.println(course1);
    }
}
